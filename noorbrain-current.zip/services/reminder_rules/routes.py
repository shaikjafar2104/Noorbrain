"""
============================================================
Project : NoorBrain
Module  : Reminder Rules API
Purpose : Dashboard API for creating and managing reminders
============================================================
"""

from typing import Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from services.reminder_rules.reminder_rules import reminder_rules
from services.activity_engine import activity_engine
from shared.person_tracker import person_tracker


router = APIRouter(tags=["Reminder Rules"])


# ---------------------------------------------------------
# Request Models
# ---------------------------------------------------------
class ReminderRulePayload(BaseModel):
    name: str = "Reminder Rule"
    trigger: str = "appeared"
    zone: Optional[str] = None
    message: str
    cooldown_seconds: int = Field(
        default=1800,
        ge=0
    )
    speak: bool = True
    media_id: Optional[str] = None
    enabled: bool = True


class ReminderTogglePayload(BaseModel):
    enabled: bool


# ---------------------------------------------------------
# Error Helpers
# ---------------------------------------------------------
def rule_not_found():
    return HTTPException(
        status_code=404,
        detail="Reminder rule not found"
    )


def invalid_rule(error: Exception):
    return HTTPException(
        status_code=400,
        detail=str(error)
    )


# ---------------------------------------------------------
# List Rules and History
# ---------------------------------------------------------
@router.get("/reminder-rules")
def get_reminder_rules(
    history_limit: int = Query(
        default=50,
        ge=1,
        le=300
    )
):
    return reminder_rules.snapshot(
        history_limit=history_limit
    )


# ---------------------------------------------------------
# Create Rule
# ---------------------------------------------------------
@router.post("/reminder-rules", status_code=201)
def create_reminder_rule(
    payload: ReminderRulePayload
):
    try:
        rule = reminder_rules.create_rule(
            payload.model_dump()
        )

        return {
            "status": "created",
            "rule": rule
        }

    except ValueError as error:
        raise invalid_rule(error)


# ---------------------------------------------------------
# Update Rule
# ---------------------------------------------------------
@router.put("/reminder-rules/{rule_id}")
def update_reminder_rule(
    rule_id: str,
    payload: ReminderRulePayload
):
    try:
        rule = reminder_rules.update_rule(
            rule_id,
            payload.model_dump()
        )

        return {
            "status": "updated",
            "rule": rule
        }

    except KeyError:
        raise rule_not_found()

    except ValueError as error:
        raise invalid_rule(error)


# ---------------------------------------------------------
# Delete Rule
# ---------------------------------------------------------
@router.delete("/reminder-rules/{rule_id}")
def delete_reminder_rule(rule_id: str):
    try:
        return reminder_rules.delete_rule(rule_id)

    except KeyError:
        raise rule_not_found()


# ---------------------------------------------------------
# Enable / Disable Rule
# ---------------------------------------------------------
@router.patch(
    "/reminder-rules/{rule_id}/toggle"
)
def toggle_reminder_rule(
    rule_id: str,
    payload: ReminderTogglePayload
):
    try:
        rule = reminder_rules.toggle_rule(
            rule_id,
            payload.enabled
        )

        return {
            "status": "updated",
            "rule": rule
        }

    except KeyError:
        raise rule_not_found()

    except ValueError as error:
        raise invalid_rule(error)


# ---------------------------------------------------------
# Test Rule
# ---------------------------------------------------------
@router.post(
    "/reminder-rules/{rule_id}/test"
)
def test_reminder_rule(rule_id: str):
    try:
        record = reminder_rules.test_rule(
            rule_id
        )

        return {
            "status": "tested",
            "result": record
        }

    except KeyError:
        raise rule_not_found()


# ---------------------------------------------------------
# Clear Reminder History
# ---------------------------------------------------------
@router.post("/reminder-history/clear")
def clear_reminder_history():
    return reminder_rules.clear_history()

# =========================================================
# Sprint 3 Camera Activity API
# =========================================================

@router.get("/camera-activity")
def get_camera_activity(
    event_limit: int = Query(default=100, ge=1, le=500)
):
    return {
        "status": "running",
        "tracker": person_tracker.snapshot(),
        "activity": activity_engine.snapshot(limit=event_limit),
        "recent_reminders": reminder_rules.history(
            limit=min(event_limit, 100)
        ),
    }


@router.post("/camera-activity/clear")
def clear_camera_activity():
    activity_result = activity_engine.clear()
    person_tracker.reset()

    return {
        "status": "cleared",
        "activity": activity_result,
        "tracker_reset": True,
    }


class CameraEventTestPayload(BaseModel):
    event_type: str = "appeared"
    person_id: int = 1
    zone: Optional[str] = None
    previous_zone: Optional[str] = None
    duration: Optional[float] = None


@router.post("/camera-activity/test-event")
def test_camera_activity_event(payload: CameraEventTestPayload):
    allowed_types = {"appeared", "stayed", "disappeared"}

    event_type = payload.event_type.strip()

    if event_type not in allowed_types:
        raise HTTPException(
            status_code=400,
            detail=(
                "event_type must be one of: "
                + ", ".join(sorted(allowed_types))
            ),
        )

    event = {
        "type": event_type,
        "person_id": payload.person_id,
        "zone": payload.zone,
        "previous_zone": payload.previous_zone,
        "duration": payload.duration,
    }

    fired = reminder_rules.handle_event(event)

    return {
        "status": "processed",
        "event": event,
        "fired_count": len(fired),
        "fired": fired,
    }

