"""
============================================================
Project : NoorBrain
Module  : Main Application
Version : 1.0.0
============================================================
"""

from typing import List
from pathlib import Path
import threading
import time

import cv2
from ai.halo import halo
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, StreamingResponse, FileResponse
from pydantic import BaseModel
from fastapi.staticfiles import StaticFiles

from shared.logger import logger
from shared.config_manager import load_config

from services.camera_client import camera_client
from services.vision_engine import vision_engine
from services.zone_engine import zone_engine
from services.event_engine import event_engine
from services.reminder_rules.routes import router as reminder_rules_router
from shared.database import database


# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------
config = load_config()


# ---------------------------------------------------------
# FastAPI
# ---------------------------------------------------------
from services.media_library.routes import router as media_library_router, api_router as media_library_api_router
app = FastAPI(
    title="NoorBrain",
    version="1.0.0"
)

# Sprint 2: Media Library API
app.include_router(media_library_router)
app.include_router(media_library_api_router)


app.include_router(reminder_rules_router)

PROJECT_ROOT = Path(__file__).resolve().parent
DASHBOARD_DIR = PROJECT_ROOT / "dashboard"
app.mount(
    "/dashboard-static",
    StaticFiles(directory=str(DASHBOARD_DIR)),
    name="dashboard-static"
)


# ---------------------------------------------------------
# Models
# ---------------------------------------------------------
class ChatRequest(BaseModel):
    message: str


class ZoneModel(BaseModel):
    name: str
    x1: int
    y1: int
    x2: int
    y2: int


class VisionSettings(BaseModel):
    confidence: float


# ---------------------------------------------------------
# Startup
# ---------------------------------------------------------
@app.on_event("startup")
def startup():
    logger.info("=" * 60)
    logger.info("Starting NoorBrain")
    logger.info("=" * 60)
    
    camera_client.start()
    vision_engine.start()
    logger.info("Vision Snapshot After Start")
    logger.info(vision_engine.snapshot())
    
    logger.info("NoorBrain Ready")


# ---------------------------------------------------------
# Shutdown
# ---------------------------------------------------------
@app.on_event("shutdown")
def shutdown():
    logger.info("=" * 60)
    logger.info("Stopping NoorBrain")
    logger.info("=" * 60)
    
    vision_engine.stop()
    camera_client.stop()
    
    logger.info("Shutdown Complete")


# ---------------------------------------------------------
# Home
# ---------------------------------------------------------
@app.get("/")
def home():
    return HTMLResponse("""
    <html>
    <head>
        <title>NoorBrain</title>
        <style>
        body{
            background:#101114;
            color:white;
            text-align:center;
            font-family:Arial;
        }
        img{
            width:900px;
            border-radius:12px;
            border:2px solid #00d084;
        }
        a{
            color:#00d084;
            margin:15px;
            text-decoration:none;
            font-weight:bold;
        }
        </style>
    </head>
    <body>
        <h1>NoorBrain</h1>
        <img src="/vision_feed">
        <br><br>
        <a href="/detections">Detections</a>
        <a href="/zones">Zones</a>
        <a href="/camera">Camera</a>
        <a href="/dashboard/zones">Dashboard</a>
    </body>
    </html>
    """)


# ---------------------------------------------------------
# Health
# ---------------------------------------------------------
@app.get("/health")
def health():
    return {
        "status": "healthy",
        "camera": camera_client.snapshot(),
        "vision": vision_engine.snapshot()
    }


# ---------------------------------------------------------
# Camera
# ---------------------------------------------------------
@app.get("/camera")
def camera():
    return camera_client.snapshot()


@app.get("/camera/stats")
def camera_stats():
    return {
        "camera": camera_client.snapshot(),
        "vision": vision_engine.snapshot()
    }


# ---------------------------------------------------------
# Detections
# ---------------------------------------------------------
@app.get("/detections")
def detections():
    people = vision_engine.get_detections()
    return {
        "count": len(people),
        "people": people
    }


# ---------------------------------------------------------
# Zones
# ---------------------------------------------------------
@app.get("/zones")
def zones():
    all_zones = zone_engine.get_all_zones()
    return {
        "count": len(all_zones),
        "zones": all_zones
    }


# ---------------------------------------------------------
# Save Zones
# ---------------------------------------------------------
@app.post("/zones/save")
def save_zones(zones: List[ZoneModel]):
    zone_engine.save_zones([
        zone.model_dump()
        for zone in zones
    ])
    return {
        "status": "saved",
        "count": len(zones)
    }


# ---------------------------------------------------------
# Frame Size
# ---------------------------------------------------------
@app.get("/frame_size")
def frame_size():
    frame = vision_engine.get_frame()
    if frame is None:
        return {
            "width": 1280,
            "height": 720
        }
    height, width = frame.shape[:2]
    return {
        "width": width,
        "height": height
    }


# ---------------------------------------------------------
# Shared MJPEG Encoder
# ---------------------------------------------------------
_jpeg_lock = threading.Lock()
_jpeg_bytes = None
_jpeg_time = 0.0
_jpeg_interval = 1.0 / 8.0


def get_encoded_frame():
    global _jpeg_bytes, _jpeg_time

    now = time.monotonic()

    with _jpeg_lock:
        if (
            _jpeg_bytes is not None
            and now - _jpeg_time < _jpeg_interval
        ):
            return _jpeg_bytes

        frame = vision_engine.get_frame()

        # Keep camera visible while vision is starting or stopped.
        if frame is None:
            frame = camera_client.get_frame()

        if frame is None:
            return None

        success, buffer = cv2.imencode(
            ".jpg",
            frame,
            [int(cv2.IMWRITE_JPEG_QUALITY), 75]
        )

        if not success:
            return None

        _jpeg_bytes = buffer.tobytes()
        _jpeg_time = now

        return _jpeg_bytes


def generate():
    while True:
        jpg = get_encoded_frame()

        if jpg is None:
            time.sleep(0.10)
            continue

        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n"
            b"Cache-Control: no-cache, no-store, must-revalidate\r\n"
            b"Pragma: no-cache\r\n\r\n"
            + jpg
            + b"\r\n"
        )

        # Each browser connection is limited to 8 FPS.
        time.sleep(_jpeg_interval)


# ---------------------------------------------------------
# Vision Feed
# ---------------------------------------------------------
@app.get("/vision_feed")
def vision_feed():
    return StreamingResponse(
        generate(),
        media_type="multipart/x-mixed-replace; boundary=frame",
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0"
        }
    )


# ---------------------------------------------------------
# Halo Chat
# ---------------------------------------------------------
@app.post("/halo")
def halo_chat(request: ChatRequest):
    reply = halo.ask(request.message)
    return {
        "success": True,
        "reply": reply
    }




# ---------------------------------------------------------
# NoorBrain AI Studio
# ---------------------------------------------------------
@app.get("/studio", include_in_schema=False)
def studio():
    return FileResponse(DASHBOARD_DIR / "index.html")


# ---------------------------------------------------------
# Event API
# ---------------------------------------------------------
@app.get("/events")
def events(limit: int = 50):
    limit = max(1, min(limit, 500))
    rows = database.recent_events(limit)
    return {
        "count": len(rows),
        "events": [
            {
                "time": row[0],
                "event": row[1],
                "zone": row[2],
                "source": row[3],
                "destination": row[4]
            }
            for row in rows
        ]
    }


# ---------------------------------------------------------
# Runtime Controls
# ---------------------------------------------------------
@app.post("/control/vision/start")
def control_vision_start():
    vision_engine.start()
    return {"success": True, "message": "Vision engine started."}


@app.post("/control/vision/stop")
def control_vision_stop():
    vision_engine.stop()
    return {"success": True, "message": "Vision engine stopped."}


@app.post("/control/vision/restart")
def control_vision_restart():
    def restart_worker():
        vision_engine.stop()
        time.sleep(1)
        vision_engine.start()

    threading.Thread(target=restart_worker, daemon=True).start()
    return {"success": True, "message": "Vision engine is restarting."}


@app.post("/control/camera/reconnect")
def control_camera_reconnect():
    def reconnect_worker():
        camera_client.stop()
        time.sleep(1)
        camera_client.start()

    threading.Thread(target=reconnect_worker, daemon=True).start()
    return {"success": True, "message": "Camera client is reconnecting."}


# ---------------------------------------------------------
# Settings API
# ---------------------------------------------------------
@app.get("/settings/vision")
def get_vision_settings():
    return {
        "model": vision_engine.model_path,
        "confidence": vision_engine.confidence
    }


@app.post("/settings/vision")
def save_vision_settings(settings: VisionSettings):
    if not 0.05 <= settings.confidence <= 0.95:
        return {
            "success": False,
            "message": "Confidence must be between 0.05 and 0.95."
        }

    vision_engine.confidence = float(settings.confidence)
    return {
        "success": True,
        "message": f"Vision confidence set to {vision_engine.confidence:.2f}.",
        "confidence": vision_engine.confidence
    }


# ---------------------------------------------------------
# Dashboard
# ---------------------------------------------------------
@app.get("/dashboard/zones")
def dashboard_zones():
    return HTMLResponse("""
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Noor AI Studio</title>
<style>
body{
    margin:0;
    background:#101114;
    color:white;
    font-family:Arial;
}
header{
    background:#18191d;
    padding:18px;
    text-align:center;
    font-size:28px;
    font-weight:bold;
}
#container{
    width:940px;
    margin:30px auto;
}
#stage{
    position:relative;
}
#video{
    width:900px;
    display:block;
    border-radius:12px;
    border:2px solid #00d084;
}
#overlay{
    position:absolute;
    left:0;
    top:0;
    cursor:crosshair;
}
#toolbar{
    margin-top:18px;
}
button{
    background:#00d084;
    border:none;
    color:#111;
    padding:10px 18px;
    border-radius:8px;
    cursor:pointer;
    font-weight:bold;
    margin-right:10px;
}
button:hover{
    opacity:.9;
}
button.danger{
    background:#ff4d4d;
    color:white;
}
#zoneList{
    margin-top:20px;
}
.zone{
    background:#1c1d22;
    padding:12px;
    border-radius:8px;
    margin-top:8px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}
</style>
</head>
<body>
<header>Noor AI Studio</header>
<div id="container">
    <div id="stage">
        <img id="video" src="/vision_feed">
        <canvas id="overlay"></canvas>
    </div>
    <div id="toolbar">
        <button onclick="saveZones()">Save Zones</button>
        <button class="danger" onclick="clearZones()">Clear</button>
    </div>
    <div id="zoneList"></div>
</div>

<script>
// ============================================================
// VARIABLES
// ============================================================
let zones = [];
let drawing = false;
let startX = 0;
let startY = 0;
let temp = null;
let actualWidth = 1280;
let actualHeight = 720;
const displayWidth = 900;
let displayHeight = 506;

const video = document.getElementById("video");
const canvas = document.getElementById("overlay");
const ctx = canvas.getContext("2d");

// ============================================================
// CANVAS SETUP
// ============================================================
async function setupCanvas() {
    const response = await fetch("/frame_size");
    const size = await response.json();
    actualWidth = size.width;
    actualHeight = size.height;
    displayHeight = Math.round(
        displayWidth *
        actualHeight /
        actualWidth
    );
    canvas.width = displayWidth;
    canvas.height = displayHeight;
    canvas.style.width = displayWidth + "px";
    canvas.style.height = displayHeight + "px";
}

// ============================================================
// COORDINATE CONVERSION
// ============================================================
function toActual(value, scale) {
    return Math.round(value * scale);
}

function toDisplay(value, scale) {
    return Math.round(value / scale);
}

// ============================================================
// DRAWING
// ============================================================
function redraw() {
    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );
    for (const zone of zones) {
        drawZone(zone);
    }
    if (temp) {
        drawZone(temp, "#00d084");
    }
}

function drawZone(zone, color = "#ffb400") {
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.strokeRect(
        zone.x1,
        zone.y1,
        zone.x2 - zone.x1,
        zone.y2 - zone.y1
    );
    ctx.fillStyle = color;
    ctx.font = "16px Arial";
    ctx.fillText(
        zone.name,
        zone.x1 + 6,
        zone.y1 + 20
    );
}

// ============================================================
// MOUSE EVENTS
// ============================================================
canvas.onmousedown = function(e) {
    const rect = canvas.getBoundingClientRect();
    drawing = true;
    startX = e.clientX - rect.left;
    startY = e.clientY - rect.top;
};

canvas.onmousemove = function(e) {
    if (!drawing) {
        return;
    }
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    temp = {
        name: "",
        x1: Math.min(startX, x),
        y1: Math.min(startY, y),
        x2: Math.max(startX, x),
        y2: Math.max(startY, y)
    };
    redraw();
};

canvas.onmouseup = function() {
    if (!drawing) {
        return;
    }
    drawing = false;
    if (!temp) {
        return;
    }
    const name = prompt("Zone Name");
    if (name) {
        temp.name = name;
        zones.push(temp);
    }
    temp = null;
    redraw();
    renderZoneList();
};

// ============================================================
// ZONE LIST
// ============================================================
function renderZoneList() {
    const container = document.getElementById("zoneList");
    container.innerHTML = "";
    zones.forEach((zone, index) => {
        const item = document.createElement("div");
        item.className = "zone";
        item.innerHTML = `
            <span>${zone.name}</span>
            <button class="danger"
                    onclick="deleteZone(${index})">
                Delete
            </button>
        `;
        container.appendChild(item);
    });
}

// ============================================================
// DELETE
// ============================================================
function deleteZone(index) {
    zones.splice(index, 1);
    redraw();
    renderZoneList();
}

// ============================================================
// CLEAR
// ============================================================
function clearZones() {
    if (!confirm("Delete all zones?")) {
        return;
    }
    zones = [];
    redraw();
    renderZoneList();
}

// ============================================================
// SAVE
// ============================================================
async function saveZones() {
    const sx = actualWidth / displayWidth;
    const sy = actualHeight / displayHeight;
    const payload = zones.map(z => ({
        name: z.name,
        x1: Math.round(z.x1 * sx),
        y1: Math.round(z.y1 * sy),
        x2: Math.round(z.x2 * sx),
        y2: Math.round(z.y2 * sy)
    }));
    const response = await fetch(
        "/zones/save",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        }
    );
    const result = await response.json();
    alert(
        "Saved "
        + result.count +
        " zones."
    );
}

// ============================================================
// LOAD EXISTING ZONES
// ============================================================
async function loadZones() {
    const response = await fetch("/zones");
    const result = await response.json();
    const sx = actualWidth / displayWidth;
    const sy = actualHeight / displayHeight;
    zones = result.zones.map(z => ({
        name: z.name,
        x1: Math.round(z.x1 / sx),
        y1: Math.round(z.y1 / sy),
        x2: Math.round(z.x2 / sx),
        y2: Math.round(z.y2 / sy)
    }));
    redraw();
    renderZoneList();
}

// ============================================================
// STARTUP
// ============================================================
window.onload = async () => {
    await setupCanvas();
    await loadZones();
    redraw();
};
</script>
</body>
</html>
    """)
