"""
============================================================
Project : Noor AI Home Platform
Module  : Camera Client
Version : 1.0.0
============================================================
"""

import threading
import time

import cv2
import numpy as np
import requests

from shared.logger import logger
from shared.config_manager import load_config
from shared.frame_buffer import frame_buffer


class CameraClient:

    def __init__(self):

        config = load_config()

        camera_node = config.get(
            "camera_node",
            {}
        )

        self.base_url = camera_node.get(
            "url",
            "http://127.0.0.1:8000"
        )

        self.stream_url = (
            self.base_url +
            "/video_feed"
        )

        self.connected = False

        self.running = False

        self.thread = None

        self.session = requests.Session()

        self.frame_count = 0

        self.current_fps = 0.0

        self.last_fps_time = time.time()

        self.last_frame_time = 0

        logger.info(

            f"Camera URL : {self.base_url}"

        )
    # ----------------------------------------------------

    def connect(self):

        logger.info("=" * 60)
        logger.info("Connecting to Camera Node")
        logger.info("=" * 60)

        while self.running:

            try:

                response = self.session.get(
                    self.stream_url,
                    stream=True,
                    timeout=10
                )

                if response.status_code == 200:

                    self.connected = True

                    logger.info(
                        "Camera Stream Connected"
                    )

                    return response

                logger.warning(
                    f"HTTP {response.status_code}"
                )

            except Exception as ex:

                logger.warning(
                    f"Connection Failed : {ex}"
                )

            self.connected = False

            logger.info(
                "Retrying in 3 seconds..."
            )

            time.sleep(3)

        return None

    # ----------------------------------------------------

    def receive_stream(self):

        while self.running:

            response = self.connect()

            if response is None:
                continue

            try:

                buffer = b""

                for chunk in response.iter_content(4096):

                    if not self.running:
                        break

                    if not chunk:
                        continue

                    buffer += chunk

                    while True:

                        start = buffer.find(b"\xff\xd8")
                        end = buffer.find(b"\xff\xd9")

                        if start == -1 or end == -1:
                            break

                        jpg = buffer[start:end + 2]

                        buffer = buffer[end + 2:]

                        self.process_frame(jpg)

            except Exception as ex:

                logger.warning(ex)

                self.connected = False

                time.sleep(2)

            finally:

                try:
                    response.close()
                except Exception:
                    pass
    # ----------------------------------------------------

    def process_frame(self, jpg):

        try:

            image = np.frombuffer(

                jpg,

                dtype=np.uint8

            )

            frame = cv2.imdecode(

                image,

                cv2.IMREAD_COLOR

            )

            if frame is None:

                return

            frame_buffer.update(frame)

            self.frame_count += 1

            self.last_frame_time = time.time()

            elapsed = (

                self.last_frame_time -

                self.last_fps_time

            )

            if elapsed >= 1.0:

                self.current_fps = (

                    self.frame_count / elapsed

                )

                logger.info(

                    f"Camera FPS : "

                    f"{self.current_fps:.2f}"

                )

                self.frame_count = 0

                self.last_fps_time = (

                    self.last_frame_time

                )

        except Exception as ex:

            logger.exception(ex)

    # ----------------------------------------------------

    def get_frame(self):

        return frame_buffer.get()

    # ----------------------------------------------------

    def is_connected(self):

        return self.connected

    # ----------------------------------------------------

    def fps(self):

        return round(

            self.current_fps,

            2

        )
    # ----------------------------------------------------

    def start(self):

        if self.running:

            return

        logger.info("=" * 60)
        logger.info("Starting Camera Client")
        logger.info("=" * 60)

        self.running = True

        self.thread = threading.Thread(
            target=self.receive_stream,
            daemon=True,
            name="CameraClient"
        )

        self.thread.start()

        logger.info("Camera Client Started")

    # ----------------------------------------------------

    def stop(self):

        logger.info("Stopping Camera Client")

        self.running = False

        if self.thread:

            self.thread.join(timeout=2)

        try:

            self.session.close()

        except Exception:
            pass

        self.connected = False

        logger.info("Camera Client Stopped")

    # ----------------------------------------------------

    def snapshot(self):

        return {

            "connected": self.connected,

            "stream_url": self.stream_url,

            "fps": round(
                self.current_fps,
                2
            ),

            "running": self.running,

            "last_frame": round(
                time.time() - self.last_frame_time,
                2
            ) if self.last_frame_time else None

        }


camera_client = CameraClient()


# ---------------------------------------------------------

if __name__ == "__main__":

    try:

        camera_client.start()

        while True:

            time.sleep(1)

            print(
                camera_client.snapshot()
            )

    except KeyboardInterrupt:

        pass

    finally:

        camera_client.stop()
