"""
============================================================
Project : NoorBrain
Module  : Vision Engine
Version : 3.0.0
Purpose : CPU-limited latest-frame person detection
============================================================
"""

import threading
import time

import cv2
from ultralytics import YOLO

from shared.scene_memory import scene_memory
from shared.logger import logger
from shared.config_manager import load_config
from shared.detection_manager import detection_manager
from shared.person_history import person_history
from shared.person_tracker import person_tracker

from services.camera_client import camera_client
from services.zone_engine import zone_engine
from services.event_engine import event_engine
from services.activity_engine import activity_engine
from services.reminder_rules import reminder_rules


class VisionEngine:

    def __init__(self):
        config = load_config()
        vision = config.get("vision", {})

        self.model_path = vision.get("model", "yolov8n.pt")
        self.confidence = float(vision.get("confidence", 0.30))

        # Performance controls
        self.target_fps = max(
            0.5,
            float(vision.get("target_fps", 3.0))
        )
        self.image_size = int(
            vision.get("image_size", 640)
        )

        self.model = YOLO(self.model_path)

        self.running = False
        self.thread = None

        self._lock = threading.Lock()
        self.latest_frame = None
        self.latest_detections = []

        self.frame_counter = 0
        self.current_fps = 0.0
        self.last_fps_time = time.monotonic()

        logger.info("=" * 60)
        logger.info("Vision Engine Initialized")
        logger.info(f"YOLO Model      : {self.model_path}")
        logger.info(f"Confidence      : {self.confidence}")
        logger.info(f"Target FPS      : {self.target_fps}")
        logger.info(f"Inference Size  : {self.image_size}")
        logger.info("=" * 60)

    # ----------------------------------------------------
    def start(self):
        if self.running:
            return

        logger.info("=" * 60)
        logger.info("Starting Vision Engine")
        logger.info("=" * 60)

        # Camera lifecycle is managed by main.py.
        if not camera_client.running:
            camera_client.start()

        self.running = True
        self.thread = threading.Thread(
            target=self.process_loop,
            daemon=True,
            name="VisionEngine"
        )
        self.thread.start()

        logger.info("Vision Engine Started")

    # ----------------------------------------------------
    def stop(self):
        if not self.running:
            return

        logger.info("Stopping Vision Engine")
        self.running = False

        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=3)

        self.thread = None

        # Do not stop camera here. Dashboard camera should stay live.
        logger.info("Vision Engine Stopped")

    # ----------------------------------------------------
    def process_loop(self):
        logger.info("Vision Processing Loop Started")

        frame_interval = 1.0 / self.target_fps
        next_run = time.monotonic()

        while self.running:
            now = time.monotonic()

            if now < next_run:
                time.sleep(min(next_run - now, 0.05))
                continue

            started = time.monotonic()
            frame = camera_client.get_frame()

            if frame is None:
                time.sleep(0.10)
                next_run = time.monotonic() + frame_interval
                continue

            try:
                # classes=[0] means person only.
                results = self.model.predict(
                    source=frame,
                    conf=self.confidence,
                    classes=[0],
                    imgsz=self.image_size,
                    verbose=False
                )[0]

            except Exception as ex:
                logger.exception(ex)
                time.sleep(0.5)
                next_run = time.monotonic() + frame_interval
                continue

            detections = []

            for box in results.boxes:
                confidence = float(box.conf[0])

                if confidence < self.confidence:
                    continue

                x1, y1, x2, y2 = map(
                    int,
                    box.xyxy[0].tolist()
                )

                zone = zone_engine.get_zone_for_box(
                    [x1, y1, x2, y2]
                )

                detections.append({
                    "label": "person",
                    "confidence": round(confidence, 2),
                    "box": [x1, y1, x2, y2],
                    "zone": zone
                })

            # Add stable person IDs across video frames.
            tracked_detections = person_tracker.update(
                detections
            )

            # A new track must be seen more than once before it
            # can create activity/reminder events. This prevents
            # one-frame false detections from firing reminders.
            active_detections = [
                detection
                for detection in tracked_detections
                if detection.get("status") == "active"
            ]

            detection_manager.update(
                tracked_detections
            )
            scene_memory.update(
                active_detections
            )
            person_history.update(
                active_detections
            )

            # Keep the original EventEngine operational for
            # existing database/history features.
            event_engine.update(
                active_detections
            )

            # Generate rich person activity events:
            # appeared, entered_zone, moved_zone, left_zone,
            # stayed and disappeared.
            activity_engine.update(
                active_detections
            )

            # Deliver each new activity event exactly once to
            # Reminder Rules. Cooldown is enforced inside the
            # ReminderRulesEngine.
            for activity_event in activity_engine.drain_events():
                try:
                    fired_reminders = (
                        reminder_rules.handle_event(
                            activity_event
                        )
                    )

                    if fired_reminders:
                        logger.info(
                            "REMINDER RULES : "
                            f"{len(fired_reminders)} fired for "
                            f"{activity_event.get('type')} "
                            f"person={activity_event.get('person_id')} "
                            f"zone={activity_event.get('zone')}"
                        )

                except Exception:
                    # Reminder failure must never stop camera
                    # processing or YOLO inference.
                    logger.exception(
                        "Reminder Rules event handling failed"
                    )

            rendered = self.render(
                frame,
                tracked_detections
            )

            with self._lock:
                self.latest_detections = list(
                    tracked_detections
                )
                self.latest_frame = rendered

            self.update_fps()

            elapsed = time.monotonic() - started
            next_run = time.monotonic() + max(
                0.0,
                frame_interval - elapsed
            )

        logger.info("Vision Processing Loop Exited")

    # ----------------------------------------------------
    def update_fps(self):
        self.frame_counter += 1
        now = time.monotonic()
        elapsed = now - self.last_fps_time

        if elapsed >= 2.0:
            self.current_fps = self.frame_counter / elapsed
            self.frame_counter = 0
            self.last_fps_time = now

    # ----------------------------------------------------
    def draw_detections(self, frame, detections):
        for detection in detections:
            x1, y1, x2, y2 = detection["box"]
            confidence = detection["confidence"]
            zone = detection["zone"]
            person_id = detection.get(
                "person_id",
                detection.get("id", 0)
            )

            cv2.rectangle(
                frame,
                (x1, y1),
                (x2, y2),
                (0, 255, 0),
                2
            )

            cv2.putText(
                frame,
                f"person {confidence:.2f} ID:{person_id}",
                (x1, max(25, y1 - 10)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 255, 0),
                2
            )

            cv2.putText(
                frame,
                f"Zone: {zone}",
                (x1, min(frame.shape[0] - 10, y2 + 20)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (0, 200, 255),
                2
            )

            # Reminder playback is handled by ActivityEngine
            # and ReminderRulesEngine. The previous per-frame
            # zone reminder call was removed to prevent duplicate
            # playback while a person remains visible.

    # ----------------------------------------------------
    def draw_zones(self, frame):
        for zone in zone_engine.get_all_zones():
            x1 = int(zone["x1"])
            y1 = int(zone["y1"])
            x2 = int(zone["x2"])
            y2 = int(zone["y2"])

            cv2.rectangle(
                frame,
                (x1, y1),
                (x2, y2),
                (255, 180, 0),
                2
            )

            cv2.putText(
                frame,
                zone["name"],
                (x1 + 6, y1 + 22),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 180, 0),
                2
            )

    # ----------------------------------------------------
    def render(self, frame, detections):
        output = frame.copy()

        self.draw_zones(output)
        self.draw_detections(output, detections)

        cv2.putText(
            output,
            f"Vision FPS: {self.current_fps:.2f}",
            (20, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (0, 255, 255),
            2
        )

        cv2.putText(
            output,
            f"Persons: {len(detections)}",
            (20, 60),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 0),
            2
        )

        return output

    # ----------------------------------------------------
    def get_frame(self):
        with self._lock:
            return self.latest_frame

    # ----------------------------------------------------
    def get_detections(self):
        with self._lock:
            return list(self.latest_detections)

    # ----------------------------------------------------
    def get_person_count(self):
        with self._lock:
            return len(self.latest_detections)

    # ----------------------------------------------------
    def snapshot(self):
        with self._lock:
            persons = len(self.latest_detections)

        return {
            "running": self.running,
            "model": self.model_path,
            "confidence": self.confidence,
            "target_fps": self.target_fps,
            "image_size": self.image_size,
            "fps": round(self.current_fps, 2),
            "persons": persons,
            "camera_connected": camera_client.is_connected(),
            "camera": camera_client.snapshot(),
            "detection_manager": detection_manager.snapshot(),
            "person_tracker": person_tracker.snapshot(),
            "activity_engine": activity_engine.snapshot(
                limit=20
            ),
            "reminder_rules": {
                "rule_count": len(
                    reminder_rules.list_rules()
                ),
                "recent_history": reminder_rules.history(
                    limit=10
                )
            }
        }


vision_engine = VisionEngine()


if __name__ == "__main__":
    try:
        camera_client.start()
        vision_engine.start()

        while True:
            time.sleep(2)
            print(vision_engine.snapshot())

    except KeyboardInterrupt:
        logger.info("Vision Engine Interrupted")

    finally:
        vision_engine.stop()
        camera_client.stop()
