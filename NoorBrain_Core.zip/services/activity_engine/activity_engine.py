"""
============================================================
Project : NoorBrain
Module  : Activity Engine
Version : 1.0.0
Purpose : Convert tracked people detections into activity events.
============================================================
"""

from collections import deque
from datetime import datetime
import threading
import time


class ActivityEngine:

    def __init__(
        self,
        disappearance_timeout=3.5,
        stay_interval=60.0,
        maximum_events=500
    ):
        self.disappearance_timeout = disappearance_timeout
        self.stay_interval = stay_interval

        self._lock = threading.RLock()
        self._people = {}
        self._events = deque(maxlen=maximum_events)

        # Events waiting to be delivered to downstream services.
        # The dashboard history remains stored in _events.
        self._pending_events = deque()

        self._next_event_id = 1

    # ----------------------------------------------------
    @staticmethod
    def _clean_zone(zone):
        if zone is None:
            return None

        zone = str(zone).strip()

        if not zone:
            return None

        if zone.lower() in {
            "unknown",
            "none",
            "outside",
            "no zone",
            "unassigned"
        }:
            return None

        return zone

    # ----------------------------------------------------
    def _add_event(
        self,
        event_type,
        person_id,
        zone=None,
        previous_zone=None,
        duration=None
    ):
        now = time.time()

        event = {
            "event_id": self._next_event_id,
            "type": event_type,
            "person_id": person_id,
            "zone": zone,
            "previous_zone": previous_zone,
            "timestamp": now,
            "time_text": datetime.fromtimestamp(
                now
            ).strftime("%Y-%m-%d %H:%M:%S")
        }

        if duration is not None:
            event["duration"] = round(duration, 1)

        event["message"] = self._message(event)

        self._events.appendleft(event)
        self._pending_events.append(dict(event))
        self._next_event_id += 1

        return event

    # ----------------------------------------------------
    @staticmethod
    def _message(event):
        person = f"Person {event['person_id']}"
        event_type = event["type"]
        zone = event.get("zone")
        previous_zone = event.get("previous_zone")
        duration = event.get("duration", 0)

        if event_type == "appeared":
            return f"{person} appeared"

        if event_type == "entered_zone":
            return f"{person} entered {zone}"

        if event_type == "moved_zone":
            return (
                f"{person} moved from "
                f"{previous_zone} to {zone}"
            )

        if event_type == "left_zone":
            return f"{person} left {zone}"

        if event_type == "stayed":
            return (
                f"{person} stayed in {zone} "
                f"for {int(duration)} seconds"
            )

        if event_type == "disappeared":
            return f"{person} disappeared"

        return f"{person}: {event_type}"

    # ----------------------------------------------------
    def update(self, detections):
        now = time.time()
        visible_ids = set()

        with self._lock:
            for detection in detections:
                person_id = detection.get(
                    "person_id",
                    detection.get("id")
                )

                if person_id is None:
                    continue

                try:
                    person_id = int(person_id)
                except (TypeError, ValueError):
                    continue

                visible_ids.add(person_id)
                zone = self._clean_zone(
                    detection.get("zone")
                )

                person = self._people.get(person_id)

                if person is None:
                    self._people[person_id] = {
                        "person_id": person_id,
                        "first_seen": now,
                        "last_seen": now,
                        "zone": zone,
                        "zone_entered_at": now,
                        "last_stay_event": now,
                        "visible": True
                    }

                    self._add_event(
                        "appeared",
                        person_id,
                        zone=zone
                    )

                    if zone:
                        self._add_event(
                            "entered_zone",
                            person_id,
                            zone=zone
                        )

                    continue

                old_zone = person.get("zone")
                person["last_seen"] = now
                person["visible"] = True

                if zone != old_zone:
                    if old_zone and zone:
                        self._add_event(
                            "moved_zone",
                            person_id,
                            zone=zone,
                            previous_zone=old_zone
                        )

                    elif old_zone and not zone:
                        self._add_event(
                            "left_zone",
                            person_id,
                            zone=old_zone
                        )

                    elif zone and not old_zone:
                        self._add_event(
                            "entered_zone",
                            person_id,
                            zone=zone
                        )

                    person["zone"] = zone
                    person["zone_entered_at"] = now
                    person["last_stay_event"] = now

                elif zone:
                    since_last_stay = (
                        now - person["last_stay_event"]
                    )

                    if since_last_stay >= self.stay_interval:
                        duration = (
                            now - person["zone_entered_at"]
                        )

                        self._add_event(
                            "stayed",
                            person_id,
                            zone=zone,
                            duration=duration
                        )

                        person["last_stay_event"] = now

            expired_ids = []

            for person_id, person in self._people.items():
                if person_id in visible_ids:
                    continue

                missing_for = now - person["last_seen"]

                if missing_for < self.disappearance_timeout:
                    person["visible"] = False
                    continue

                old_zone = person.get("zone")

                if old_zone:
                    self._add_event(
                        "left_zone",
                        person_id,
                        zone=old_zone
                    )

                self._add_event(
                    "disappeared",
                    person_id,
                    zone=old_zone,
                    duration=now - person["first_seen"]
                )

                expired_ids.append(person_id)

            for person_id in expired_ids:
                del self._people[person_id]


    # ----------------------------------------------------
    def drain_events(self):
        """
        Return newly-created events exactly once.

        VisionEngine uses this method to deliver activity
        events to ReminderRulesEngine without replaying old
        dashboard history.
        """
        with self._lock:
            events = list(self._pending_events)
            self._pending_events.clear()
            return events

    # ----------------------------------------------------
    def events(self, limit=100):
        try:
            limit = max(1, min(int(limit), 500))
        except (TypeError, ValueError):
            limit = 100

        with self._lock:
            return list(self._events)[:limit]

    # ----------------------------------------------------
    def active_people(self):
        now = time.time()

        with self._lock:
            return [
                {
                    "person_id": person["person_id"],
                    "zone": person["zone"],
                    "visible": person["visible"],
                    "first_seen": person["first_seen"],
                    "last_seen": person["last_seen"],
                    "seen_for": round(
                        now - person["first_seen"],
                        1
                    ),
                    "zone_duration": round(
                        now - person["zone_entered_at"],
                        1
                    )
                }
                for person in self._people.values()
            ]

    # ----------------------------------------------------
    def snapshot(self, limit=100):
        with self._lock:
            return {
                "status": "running",
                "active_count": len(self._people),
                "event_count": len(self._events),
                "disappearance_timeout":
                    self.disappearance_timeout,
                "stay_interval": self.stay_interval,
                "active_people": self.active_people(),
                "events": self.events(limit)
            }

    # ----------------------------------------------------
    def clear(self):
        with self._lock:
            self._events.clear()
            self._pending_events.clear()
            self._people.clear()
            self._next_event_id = 1

        return {
            "status": "cleared"
        }


activity_engine = ActivityEngine()
