"""
============================================================
Project : NoorBrain
Module  : Event Engine
Version : 1.0.0
Purpose : Tracks movement and events over time
============================================================
"""

import time

from shared.logger import logger
from shared.database import database


class EventEngine:

    def __init__(self):

        self.events = []
        self.current_zone = None
        self.last_seen = None

    # ----------------------------------------------------

    def update(self, detections):

        now = time.time()

        if not detections:

            if self.current_zone is not None:

                self.events.append({
                    "time": now,
                    "event": "left",
                    "zone": self.current_zone
                })

                database.add_event(
                    now,
                    "left",
                    zone=self.current_zone
                )

                logger.info(f"EVENT : Left {self.current_zone}")

                self.current_zone = None

            return

        zone = detections[0].get("zone", "Unknown")

        if self.current_zone is None:

            self.current_zone = zone

            self.events.append({
                "time": now,
                "event": "entered",
                "zone": zone
            })

            database.add_event(
                now,
                "entered",
                zone=zone
            )

            logger.info(f"EVENT : Entered {zone}")

        elif zone != self.current_zone:

            old = self.current_zone

            self.current_zone = zone

            self.events.append({
                "time": now,
                "event": "moved",
                "from": old,
                "to": zone
            })

            database.add_event(
                now,
                "moved",
                source=old,
                destination=zone
            )

            logger.info(f"EVENT : {old} -> {zone}")

        self.last_seen = now

    # ----------------------------------------------------

    def recent(self, count=20):

        return self.events[-count:]

    # ----------------------------------------------------

    def history(self):
        return list(self.events)

    # ----------------------------------------------------

    def current(self):

        return self.current_zone

    # ----------------------------------------------------

    def snapshot(self):

        return {
            "current_zone": self.current_zone,
            "events": len(self.events),
            "last_seen": self.last_seen
        }


event_engine = EventEngine()
